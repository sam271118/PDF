# Unit Converter
Unit converter app. 
+ It is my initial steps using javascript and css3.
+ The objetive is to do a web apps capable to realise the convertion from power unit to energy equivalent in a period of time and the oil or gas consumtion to produce that energy in a termoplant

##To see the result visit:
+ http://converter-yaritagua.rhcloud.com/

Template used:
==
plate-box
HTML5 boiler plat with bootstrap support and fontawesome support... Included semantic HTML :P

